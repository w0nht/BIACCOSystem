import { createRouteHandler } from "uploadthing/next";
import { ourFileRouter } from "@/app/api/uploadthing/core"; // Você criará este arquivo

export const { GET, POST } = createRouteHandler({
  router: ourFileRouter,
});